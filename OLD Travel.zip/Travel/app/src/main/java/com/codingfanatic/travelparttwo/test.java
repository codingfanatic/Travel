package com.codingfanatic.travelparttwo;

class test{
    public static void main(String[] args){
        Home first = new Home(Home.ADDRESS_TWO);

        System.out.println(first);
    }
}